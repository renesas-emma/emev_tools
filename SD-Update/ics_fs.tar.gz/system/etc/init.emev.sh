#!/system/bin/sh

chmod 666 /sys/power/sleep_while_idle

insmod /lib/modules/inter_dsp.ko
insmod /lib/modules/em_ave.ko

busybox mknod /dev/ave c 125 0
busybox mkdir /dev/InterDSP
busybox mknod /dev/InterDSP/datamgr c 251 20
busybox mknod /dev/InterDSP/control c 251 16
busybox chown 0:1003 /dev/ave
busybox chown 0:1003 /dev/InterDSP/datamgr
busybox chown 0:1003 /dev/InterDSP/control
busybox insmod /system/lib/modules/inter_dsp.ko
busybox insmod /system/lib/modules/em_ave.ko


 
ln -s /dev/v4l/video0 /dev/video0
ln -s /dev/v4l/video1 /dev/video1

mkdir /dev/fb
ln -s /dev/graphics/fb0 /dev/fb/0

/system/vendor/bin/pvrsrvctl --start

